#include <iostream>
#include <utility>
#include <vector>
#include <map>

using namespace std;

class Solution {
public:
   bool IsPossible(vector<int>& stones);
};
